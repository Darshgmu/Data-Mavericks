import networkx as nx
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy
import os
import pickle




def getSceneBase():
    default_node = [1,0,1,0,0,0,0,0,0,0,0,0,0,19,330,1,0.01,0,1,1,255,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0.1,0,50,101,101,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,12,6,1,65536032,0,0,0,420] 
    dtypes = {i: np.int32 for i in range(len(default_node))}
    dtypes[16] = np.float64
    dtypes[22] = np.float64
    dtypes[23] = np.float64
    dtypes[24] = np.float64
    dtypes[25] = np.float64
    dtypes[26] = np.float64
    dtypes[27] = np.float64
    dtypes[28] = np.float64
    dtypes[29] = np.float64
    dtypes[30] = np.float64
    dtypes[37] = np.float64
    dtypes[38] = np.float64
    dtypes[53] = np.float64
    dtypes[80] = np.float64
    base_df = pd.read_csv("node_base.csv", dtype=dtypes)
    return base_df

def getNodeDefault():
    default_node = [1,5,1,0,0,0,0,0,0,0,0,0,0,19,330,1,0.01,0,1,1,255,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0.1,0,50,101,101,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,12,6,1,65536032,0,0,0,420]
    base_df = getSceneBase()
    test_df = pd.DataFrame([default_node], columns=base_df.columns)
    return test_df

print(os.getcwd())
G = None
print("Attempting to read graph.graphml")
G = nx.read_graphml("graph.graphml")
sceneDF = getSceneBase()

if(G == None ):
    print("Could not load graph.graphml")
    G = nx.DiGraph()
    print("processData")
    dataDtypes = {i: np.int32 for i in range(12)}
    dataDtypes[3] = np.float64
    dataDtypes[4] = np.float64
    dataDtypes[10] = np.str_
    df = pd.read_csv("data.csv", dtype=dataDtypes)
    df['Value'] = pd.to_numeric(df['Value'], errors='coerce')
    print(df['Value'])
    dfFilter = df[(df['Goal'] == 2) & (df['Objective'] == 5) & (df['Subcategory'] == 1)]
    print(dfFilter.max())
    print(dfFilter.max()['Value'])  
    print(dfFilter.min()['Value'])
    
    rowIndex = 0
    countryNodeIds = []

    for row in df.iloc:
        #if(rowIndex == 300): break
        print(str(rowIndex) + " of " + str(df.shape[0]))
        rowIndex += 1
        countryNodeId   = str(row['GeoAreaCode']) 
        if countryNodeId not in countryNodeIds:
            countryNodeIds.append(countryNodeId)
            G.add_node( countryNodeId ) # Add country node
        yearNodeId      = ( countryNodeId + "-" + str(row['Year']) )
#        print("yearNodeId: ", yearNodeId)
        goalNodeId      = ( yearNodeId + "-" + str(row['Goal']) )
 #       print("goalNodeId: ", goalNodeId)
        objectiveNodeId = ( goalNodeId + "-" + str(row['Objective']) )
  #      print("objectiveNodeId: ", objectiveNodeId)
        subcategoryNodeId = ( objectiveNodeId + "-" + str(row['Subcategory']) )
        valueNodeId = (subcategoryNodeId + "-" + str(row['Value']))
        G.nodes[countryNodeId]['Latitude'] = row['Latitude']
        G.nodes[countryNodeId]['Longitude'] = row['Longitude']
        G.add_node( yearNodeId ) #add year node
        G.add_node( goalNodeId ) #add goal node
        G.add_node( objectiveNodeId )
        G.add_node( subcategoryNodeId )
        G.add_node( valueNodeId )
        G.add_edge( countryNodeId, yearNodeId ) # link country and year node
        G.add_edge( yearNodeId, goalNodeId )
        G.add_edge( goalNodeId, objectiveNodeId )
        G.add_edge( objectiveNodeId, subcategoryNodeId )
        G.add_edge( subcategoryNodeId, valueNodeId )
        G.nodes[valueNodeId]['Value_Mapping'] = str(row['Value_Mapping'])
    nx.write_graphml(G, "graph.graphml")
    with open('countryNodeList.pickle', 'wb') as file:
        pickle.dump(countryNodeIds, file)
else:
    print("opened graph.graphml file")
    with open('countryNodeList.pickle', 'rb') as file:
        countryNodeIds = pickle.load(file)
    dataDtypes = {i: np.int32 for i in range(12)}
    dataDtypes[3] = np.float64
    dataDtypes[4] = np.float64
    dataDtypes[10] = np.str_
    df = pd.read_csv("data.csv", dtype=dataDtypes)
    df['Value'] = pd.to_numeric(df['Value'], errors='coerce')

countryMap = {}
yearMap = {}
goalMap = {}
objectiveMap = {}
subcategoryMap = {}
valueMap = {}

nodes = G.nodes()
nodeId = 10
nodeIndex = 0


print(countryNodeIds)
#print(nodes['8'])
cLimit = 0 # Country Limit
for countryIndex in countryNodeIds:
    print(str(cLimit) + " of " + str(len(countryNodeIds)))
    if(cLimit == 3): break; #Comment out to remove country limit
    cLimit += 1
    yearMap = {}
    goalMap = {}
    objectiveMap = {}
    subcategoryMap = {}
    valueMap = {}
    countryYears = G.edges([countryIndex])
    countryDF = getNodeDefault()
    countryMap[countryIndex] = nodeId
    countryDF['np_node_id'] = countryMap[countryIndex]
    countryDF['translate_x'] = G.nodes[countryIndex]['Longitude']
    countryDF['translate_y'] = G.nodes[countryIndex]['Latitude']
    sceneDF = pd.concat([sceneDF, countryDF], ignore_index=True)
    countryNodeTmp = nodeId
    nodeId += 1
    x = 0
   # print("countryYears: ", countryYears)
    for yearTup in countryYears:
        yearId = yearTup[1]
        yearGoals = G.edges([yearId])
        yearDF = getNodeDefault()
        yearMap[yearId] = nodeId
        yearDF['np_node_id'] = yearMap[yearId]
        yearDF['np_geometry_id'] = 3
        yearDF['translate_z'] = x * 1.25
        x += 1
        nodeId += 1
        yearDF['parent_id'] = countryMap[countryIndex]
        sceneDF = pd.concat([sceneDF, yearDF], ignore_index=True)
        #print("yearGoals: ", yearGoals)
        #print(yearTup[1])
        y = 0
        for goalTup in yearGoals:
            goalId = goalTup[1]
            goalDF = getNodeDefault()
            goalMap[goalId] = nodeId
            goalDF['np_node_id'] = goalMap[goalId]
            goalDF['np_geometry_id'] = 5
            goalDF['parent_id'] = yearMap[yearId]
            goalDF['translate_x'] = y * 8.25
            goalObjectives = G.edges([goalId])
            nodeId += 1
            y += 1
            sceneDF = pd.concat([sceneDF, goalDF], ignore_index=True)
            #print("Goal Objective: ", goalObjectives)
            #print(goalTup[1])
            z = 0
            for goalObjTup in goalObjectives:
                objectiveId = goalObjTup[1]
                objectiveSubcategories = G.edges([objectiveId])
                objectiveDF = getNodeDefault()
                objectiveMap[objectiveId] = nodeId
                nodeId += 1
                objectiveDF['np_node_id'] = objectiveMap[objectiveId]
                objectiveDF['np_geometry_id'] = 7
                objectiveDF['np_topo_id'] = 6
                objectiveDF['parent_id'] = goalMap[goalId]
                objectiveDF['translate_x'] = z * 8.25
                z += 1
                #print("Objective Subcategory: ", objectiveSubcategories)
                sceneDF = pd.concat([sceneDF, objectiveDF], ignore_index=True)
                for subcategoryValueTup in objectiveSubcategories:
                    subcategoryId = subcategoryValueTup[1]
                    subcategoryValues = G.edges([subcategoryId])
                    subcategoryDF = getNodeDefault()
                    subcategoryMap[subcategoryId] = nodeId
                    nodeId += 1
                    subcategoryDF['np_node_id'] = subcategoryMap[subcategoryId]
                    subcategoryDF['np_geometry_id'] = 9
                    subcategoryDF['parent_id'] = objectiveMap[objectiveId]
                    sceneDF = pd.concat([sceneDF, subcategoryDF], ignore_index=True)
    #                print("Values: ", subcategoryValues)
                    for valueTup in subcategoryValues:
                        #print("value: ", valueTup[1])
                        splitValue = valueTup[1].split('-')
      #                  print(splitValue[len(splitValue)-1])
     #                   print("Value_Mapping: ",G.nodes[valueTup[1]]['Value_Mapping'])
                        valueId = valueTup[1]
                        valueDF = getNodeDefault()
                        valueMap[valueId] = nodeId
                        nodeId += 1
                        valueDF['np_node_id'] = valueMap[valueId]
                        valueDF['np_geometry_id'] = 11
                        valueDF['parent_id'] = objectiveMap[objectiveId]
                        if G.nodes[valueTup[1]]['Value_Mapping'] == 1.0:
       #                     print("Percentage")
                            if( splitValue[len(splitValue)-1][0] == '>' or splitValue[len(splitValue)-1][0] == '<' ):
                                continue
                            valueDF['scale_x'] = valueDF['scale_y'] = valueDF['scale_z'] = (float(splitValue[len(splitValue)-1]) / 100.0) * 8.0
                            sceneDF = pd.concat([sceneDF, valueDF], ignore_index=True)
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "2.0":
        #                    print("Count") 
                            #print(splitValue)
         #                   print(splitValue[5])
                            if(splitValue[5] == "nan" or splitValue[5] == "NaN" or splitValue[5] == np.nan or splitValue[5][0] == "<" or splitValue[5][0] == ">"): 
                                continue
                            filteredDF = df[ (df['Goal'] == float(splitValue[2]) ) & (df['Objective'] == float(splitValue[3])) & (df['Subcategory'] == float(splitValue[4])) ]
#                            print(filteredDF.max(skipna=True))
#                            calculatedVal = (float(splitValue[5]) / float(filteredDF.max(skipna=True)['Value']))
#                            print("calculatedVal: ", calculatedVal)
                            if( filteredDF.max(skipna=True)['Value'] != 0): 
                                valueDF['scale_x'] = valueDF['scale_y'] = valueDF['scale_z'] = (float(splitValue[5]) / float(filteredDF.max(skipna=True)['Value'])) * 50
                                valueDF['np_geometry_id'] = 13
                                sceneDF = pd.concat([sceneDF, valueDF], ignore_index=True)
                    #       dfFilter = df[(df['Goal'] == 1) & (df['Objective'] == 1) & (df['Subcategory'] == 1)]
                            #print(filteredDF)
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "3":
                            print("Population")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "4":
                            print("CU_USD USD")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "5":
                            print("CU_USD_M USD")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "6":
                            print("Index")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "7":
                            print("MJ_PER_GDP_CON_PPP_USD :: GDP USD")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "8":
                            print("CON_USD_M :: USD")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "9":
                            print("W_PER_CAPITA :: Capita")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "10":
                            print("NUM_M :: Count")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "11":
                            print("NUM_TH :: Count")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "12":
                            print("PER_POP_U5 :: Population")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "13":
                            print("CON_PPP_USD :: Population_USD")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "14":
                            print("CUR_LCU_M :: Currency")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "15":
                            print("Ratio :: Ratio")
                        elif G.nodes[valueTup[1]]['Value_Mapping'] == "16":
                            print("PER_100_POP :: Population")
                        
#for countryId in countryNodeIds:
#    print(countryId)
#    print(G.edges(nodes[countryId]))

print("writing csv file")
sceneDF.to_csv("output.csv", index=False)
print("finished writing csv file")

